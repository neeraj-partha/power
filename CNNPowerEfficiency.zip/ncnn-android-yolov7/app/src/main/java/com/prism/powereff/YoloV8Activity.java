package com.prism.powereff;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.elvishew.xlog.LogConfiguration;
import com.elvishew.xlog.LogLevel;
import com.elvishew.xlog.XLog;
import com.elvishew.xlog.printer.Printer;
import com.elvishew.xlog.printer.file.FilePrinter;
import com.elvishew.xlog.printer.file.backup.NeverBackupStrategy;

import java.io.File;

public class YoloV8Activity extends Activity implements SurfaceHolder.Callback {

    public static final int REQUEST_CAMERA = 100;

    private NcnnYolov8 ncnnyolov8 = new NcnnYolov8();

    private int facing = 0;

    private Spinner spinnerModel;
    private Spinner spinnerCPUGPU;
    private int current_model = 0;
    private int current_cpugpu = 0;

    private SurfaceView cameraView;

    private BatteryManager mBatteryManager;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yolo_v8);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        cameraView = (SurfaceView) findViewById(R.id.cameraview);

        cameraView.getHolder().setFormat(PixelFormat.RGBA_8888);
        cameraView.getHolder().addCallback(this);

        mBatteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);

        //delete file before logging
        File file = new File(getFilesDir().getAbsolutePath()+"/log");
        if (file.exists()) {
            file.delete();
        }

        LogConfiguration config = new LogConfiguration.Builder()
                .logLevel(LogLevel.ALL)
                .tag("POWER EFFICIENCY")
                .build();

        Printer filePrinter = new FilePrinter                       // Printer that print(save) the log to file
                .Builder(getFilesDir().getAbsolutePath())           // Specify the directory path of log file(s)
                .backupStrategy(new NeverBackupStrategy())          // Default: FileSizeBackupStrategy(1024 * 1024)
                .build();

        XLog.init(config, filePrinter);

        /*
        final Handler handler = new Handler();
        final int delay = 5000; // 1000 milliseconds == 1 second

        handler.postDelayed(new Runnable() {
            public void run() {
                //Log.d("POWER EFFICIENCY", "surfaceChanged called");
                Long avgCurrent = null, currentNow = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    //avgCurrent = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE);
                    currentNow = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                }
                //Log.d("POWER EFFICIENCY", "BATTERY_PROPERTY_CURRENT_AVERAGE = " + avgCurrent + "mAh");
                Log.d("POWER EFFICIENCY", "BATTERY_PROPERTY_CURRENT_NOW =  " + currentNow + "mAh");

                handler.postDelayed(this, delay);
            }
        }, delay);
        */

        Button buttonSwitchCamera = (Button) findViewById(R.id.buttonSwitchCamera);
        buttonSwitchCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                int new_facing = 1 - facing;
                ncnnyolov8.closeCamera();
                ncnnyolov8.openCamera(new_facing);
                facing = new_facing;
            }
        });

        Button buttonPowerProfile = (Button) findViewById(R.id.buttonPowerProfile);
        buttonPowerProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //delete file before logging
                File file = new File(getFilesDir().getAbsolutePath()+"/log");
                if (file.exists()) {
                    file.delete();
                }
                //Declare timer
                CountDownTimer cTimer = new CountDownTimer(30000, 1000) {

                    public void onTick(long millisUntilFinished) {
                        //mTextField.setText("seconds remaining: " + millisUntilFinished / 1000);
                        buttonPowerProfile.setClickable(false);
                        Long avgCurrent = null, currentNow = null;
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                            avgCurrent = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE);
                            currentNow = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                        }
                        //Log.d("POWER EFFICIENCY", "BATTERY_PROPERTY_CURRENT_AVERAGE = " + avgCurrent + "mAh");
                        XLog.d("BATTERY_PROPERTY_CURRENT_AVERAGE = " + avgCurrent + "mAh");
                        XLog.d("BATTERY_PROPERTY_CURRENT_REALTIME =  " + currentNow + "mAh");
                    }

                    public void onFinish() {
                        //mTextField.setText("done!");
                        buttonPowerProfile.setClickable(true);
                        Toast.makeText(getApplicationContext(), "Power readings saved", Toast.LENGTH_LONG);
                    }
                }.start();

            }
        });

        spinnerModel = (Spinner) findViewById(R.id.spinnerModel);
        spinnerModel.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id)
            {
                if (position != current_model)
                {
                    current_model = position;
                    reload_v8();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0)
            {
            }
        });

        spinnerCPUGPU = (Spinner) findViewById(R.id.spinnerCPUGPU);
        spinnerCPUGPU.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id)
            {
                if (position != current_cpugpu)
                {
                    current_cpugpu = position;
                    reload_v8();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0)
            {
            }
        });

        reload_v8();
    }

    private void reload_v8()
    {
        boolean ret_init = ncnnyolov8.loadModel(getAssets(), 0, current_cpugpu);
        if (!ret_init)
        {
            Log.e("MainActivity", "ncnnyolov8 loadModel failed");
        }

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
    {
        ncnnyolov8.setOutputWindow(holder.getSurface());
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder)
    {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder)
    {
        ncnnyolov8.closeCamera();
    }


    @Override
    public void onResume()
    {
        super.onResume();

        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, REQUEST_CAMERA);
        }

        ncnnyolov8.openCamera(facing);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        ncnnyolov8.closeCamera();
    }

}
